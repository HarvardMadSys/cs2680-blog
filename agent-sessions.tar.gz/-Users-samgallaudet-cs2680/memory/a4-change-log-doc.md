---
name: a4-change-log-doc
description: The user wants every change to the assignment 4 agent recorded in a shared Claude Doc change log
metadata:
  node_type: memory
  type: project
  originSessionId: 7c368c15-59ad-405a-b3b3-da7788315121
  modified: 2026-11-05T18:46:50.304Z
---

The user asked (2026-11-05) for a document that tracks all changes Claude makes to the
assignment 4 agent (`assignment4/starter_code/src/`) and its setup. It is a Claude Doc:
"Assignment 4 Agent Change Log", https://claude.ai/artifact/JiT9snSLefrheaPpKschLG
(doc id 8f74f81b-3a4e-4505-8052-00a3da08ef95).

**Why:** they want one place to see what changed, why, and how it was tested.

**How to apply:** after committing a change to the A4 agent or its EC2/tunnel setup, add a
row at the top of the Overview changelog table (date, commit, change) and a section for it,
and update the Config switches and Open items sections. Read the doc first; the user may
have edited it.
